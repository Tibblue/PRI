não consegi corrigir o ficheiro,
contudo ainda consegi descarrega-lo para o output.txt

assim sendo continuei o exercicio, 
usando o dataset providenciado pelo professor