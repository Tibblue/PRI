#!/bin/bash
mongoimport.exe -d myCinema -c movies --file new_movies.json --jsonArray