// Generated from eventos.g4 by ANTLR 4.5.1
// jshint ignore: start
var antlr4 = require('antlr4/index');


var serializedATN = ["\u0003\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd",
    "\u0002\u0011\u0083\b\u0001\u0004\u0002\t\u0002\u0004\u0003\t\u0003\u0004",
    "\u0004\t\u0004\u0004\u0005\t\u0005\u0004\u0006\t\u0006\u0004\u0007\t",
    "\u0007\u0004\b\t\b\u0004\t\t\t\u0004\n\t\n\u0004\u000b\t\u000b\u0004",
    "\f\t\f\u0004\r\t\r\u0004\u000e\t\u000e\u0004\u000f\t\u000f\u0004\u0010",
    "\t\u0010\u0004\u0011\t\u0011\u0003\u0002\u0003\u0002\u0003\u0002\u0003",
    "\u0002\u0003\u0002\u0003\u0002\u0003\u0002\u0003\u0002\u0003\u0003\u0003",
    "\u0003\u0003\u0003\u0003\u0003\u0003\u0003\u0003\u0003\u0003\u0004\u0003",
    "\u0004\u0003\u0004\u0003\u0004\u0003\u0004\u0003\u0004\u0003\u0005\u0003",
    "\u0005\u0003\u0005\u0003\u0005\u0003\u0005\u0003\u0005\u0003\u0005\u0003",
    "\u0005\u0003\u0006\u0003\u0006\u0003\u0006\u0003\u0006\u0003\u0006\u0003",
    "\u0006\u0003\u0006\u0003\u0006\u0003\u0006\u0003\u0006\u0003\u0006\u0003",
    "\u0007\u0003\u0007\u0003\u0007\u0003\u0007\u0003\u0007\u0003\u0007\u0003",
    "\u0007\u0003\b\u0003\b\u0003\t\u0003\t\u0003\t\u0003\t\u0003\t\u0003",
    "\t\u0003\t\u0003\t\u0003\t\u0003\t\u0003\t\u0003\t\u0003\t\u0003\t\u0003",
    "\t\u0003\n\u0003\n\u0003\u000b\u0003\u000b\u0003\f\u0003\f\u0003\r\u0003",
    "\r\u0003\u000e\u0006\u000el\n\u000e\r\u000e\u000e\u000em\u0003\u000f",
    "\u0003\u000f\u0003\u0010\u0003\u0010\u0007\u0010t\n\u0010\f\u0010\u000e",
    "\u0010w\u000b\u0010\u0003\u0010\u0003\u0010\u0003\u0011\u0005\u0011",
    "|\n\u0011\u0003\u0011\u0003\u0011\u0005\u0011\u0080\n\u0011\u0003\u0011",
    "\u0003\u0011\u0002\u0002\u0012\u0003\u0003\u0005\u0004\u0007\u0005\t",
    "\u0006\u000b\u0007\r\b\u000f\t\u0011\n\u0013\u000b\u0015\f\u0017\r\u0019",
    "\u000e\u001b\u000f\u001d\u0002\u001f\u0010!\u0011\u0003\u0002\u0005",
    "\u0003\u00022;\u0003\u0002$$\u0004\u0002\u000b\u000b\"\"\u0085\u0002",
    "\u0003\u0003\u0002\u0002\u0002\u0002\u0005\u0003\u0002\u0002\u0002\u0002",
    "\u0007\u0003\u0002\u0002\u0002\u0002\t\u0003\u0002\u0002\u0002\u0002",
    "\u000b\u0003\u0002\u0002\u0002\u0002\r\u0003\u0002\u0002\u0002\u0002",
    "\u000f\u0003\u0002\u0002\u0002\u0002\u0011\u0003\u0002\u0002\u0002\u0002",
    "\u0013\u0003\u0002\u0002\u0002\u0002\u0015\u0003\u0002\u0002\u0002\u0002",
    "\u0017\u0003\u0002\u0002\u0002\u0002\u0019\u0003\u0002\u0002\u0002\u0002",
    "\u001b\u0003\u0002\u0002\u0002\u0002\u001f\u0003\u0002\u0002\u0002\u0002",
    "!\u0003\u0002\u0002\u0002\u0003#\u0003\u0002\u0002\u0002\u0005+\u0003",
    "\u0002\u0002\u0002\u00071\u0003\u0002\u0002\u0002\t7\u0003\u0002\u0002",
    "\u0002\u000b?\u0003\u0002\u0002\u0002\rJ\u0003\u0002\u0002\u0002\u000f",
    "Q\u0003\u0002\u0002\u0002\u0011S\u0003\u0002\u0002\u0002\u0013b\u0003",
    "\u0002\u0002\u0002\u0015d\u0003\u0002\u0002\u0002\u0017f\u0003\u0002",
    "\u0002\u0002\u0019h\u0003\u0002\u0002\u0002\u001bk\u0003\u0002\u0002",
    "\u0002\u001do\u0003\u0002\u0002\u0002\u001fq\u0003\u0002\u0002\u0002",
    "!\u007f\u0003\u0002\u0002\u0002#$\u0007G\u0002\u0002$%\u0007x\u0002",
    "\u0002%&\u0007g\u0002\u0002&\'\u0007p\u0002\u0002\'(\u0007v\u0002\u0002",
    "()\u0007q\u0002\u0002)*\u0007<\u0002\u0002*\u0004\u0003\u0002\u0002",
    "\u0002+,\u0007F\u0002\u0002,-\u0007c\u0002\u0002-.\u0007v\u0002\u0002",
    "./\u0007c\u0002\u0002/0\u0007<\u0002\u00020\u0006\u0003\u0002\u0002",
    "\u000212\u0007J\u0002\u000223\u0007q\u0002\u000234\u0007t\u0002\u0002",
    "45\u0007c\u0002\u000256\u0007<\u0002\u00026\b\u0003\u0002\u0002\u0002",
    "78\u0007N\u0002\u000289\u0007q\u0002\u00029:\u0007e\u0002\u0002:;\u0007",
    "c\u0002\u0002;<\u0007n\u0002\u0002<=\u0007<\u0002\u0002=>\u0007\"\u0002",
    "\u0002>\n\u0003\u0002\u0002\u0002?@\u0007F\u0002\u0002@A\u0007g\u0002",
    "\u0002AB\u0007u\u0002\u0002BC\u0007e\u0002\u0002CD\u0007t\u0002\u0002",
    "DE\u0007k\u0002\u0002EF\u0007e\u0002\u0002FG\u0007c\u0002\u0002GH\u0007",
    "q\u0002\u0002HI\u0007<\u0002\u0002I\f\u0003\u0002\u0002\u0002JK\u0007",
    "E\u0002\u0002KL\u0007w\u0002\u0002LM\u0007u\u0002\u0002MN\u0007v\u0002",
    "\u0002NO\u0007q\u0002\u0002OP\u0007<\u0002\u0002P\u000e\u0003\u0002",
    "\u0002\u0002QR\u0007\u20ae\u0002\u0002R\u0010\u0003\u0002\u0002\u0002",
    "ST\u0007R\u0002\u0002TU\u0007c\u0002\u0002UV\u0007t\u0002\u0002VW\u0007",
    "v\u0002\u0002WX\u0007k\u0002\u0002XY\u0007e\u0002\u0002YZ\u0007k\u0002",
    "\u0002Z[\u0007r\u0002\u0002[\\\u0007c\u0002\u0002\\]\u0007p\u0002\u0002",
    "]^\u0007v\u0002\u0002^_\u0007g\u0002\u0002_`\u0007u\u0002\u0002`a\u0007",
    "<\u0002\u0002a\u0012\u0003\u0002\u0002\u0002bc\u0007.\u0002\u0002c\u0014",
    "\u0003\u0002\u0002\u0002de\u00070\u0002\u0002e\u0016\u0003\u0002\u0002",
    "\u0002fg\u0007/\u0002\u0002g\u0018\u0003\u0002\u0002\u0002hi\u0007<",
    "\u0002\u0002i\u001a\u0003\u0002\u0002\u0002jl\u0005\u001d\u000f\u0002",
    "kj\u0003\u0002\u0002\u0002lm\u0003\u0002\u0002\u0002mk\u0003\u0002\u0002",
    "\u0002mn\u0003\u0002\u0002\u0002n\u001c\u0003\u0002\u0002\u0002op\t",
    "\u0002\u0002\u0002p\u001e\u0003\u0002\u0002\u0002qu\u0007$\u0002\u0002",
    "rt\n\u0003\u0002\u0002sr\u0003\u0002\u0002\u0002tw\u0003\u0002\u0002",
    "\u0002us\u0003\u0002\u0002\u0002uv\u0003\u0002\u0002\u0002vx\u0003\u0002",
    "\u0002\u0002wu\u0003\u0002\u0002\u0002xy\u0007$\u0002\u0002y \u0003",
    "\u0002\u0002\u0002z|\u0007\u000f\u0002\u0002{z\u0003\u0002\u0002\u0002",
    "{|\u0003\u0002\u0002\u0002|}\u0003\u0002\u0002\u0002}\u0080\u0007\f",
    "\u0002\u0002~\u0080\t\u0004\u0002\u0002\u007f{\u0003\u0002\u0002\u0002",
    "\u007f~\u0003\u0002\u0002\u0002\u0080\u0081\u0003\u0002\u0002\u0002",
    "\u0081\u0082\b\u0011\u0002\u0002\u0082\"\u0003\u0002\u0002\u0002\u0007",
    "\u0002mu{\u007f\u0003\b\u0002\u0002"].join("");


var atn = new antlr4.atn.ATNDeserializer().deserialize(serializedATN);

var decisionsToDFA = atn.decisionToState.map( function(ds, index) { return new antlr4.dfa.DFA(ds, index); });

function gestaoEventosLexer(input) {
	antlr4.Lexer.call(this, input);
    this._interp = new antlr4.atn.LexerATNSimulator(this, atn, decisionsToDFA, new antlr4.PredictionContextCache());
    return this;
}

gestaoEventosLexer.prototype = Object.create(antlr4.Lexer.prototype);
gestaoEventosLexer.prototype.constructor = gestaoEventosLexer;

gestaoEventosLexer.EOF = antlr4.Token.EOF;
gestaoEventosLexer.T__0 = 1;
gestaoEventosLexer.T__1 = 2;
gestaoEventosLexer.T__2 = 3;
gestaoEventosLexer.T__3 = 4;
gestaoEventosLexer.T__4 = 5;
gestaoEventosLexer.T__5 = 6;
gestaoEventosLexer.T__6 = 7;
gestaoEventosLexer.T__7 = 8;
gestaoEventosLexer.T__8 = 9;
gestaoEventosLexer.T__9 = 10;
gestaoEventosLexer.T__10 = 11;
gestaoEventosLexer.T__11 = 12;
gestaoEventosLexer.NUMERO = 13;
gestaoEventosLexer.STRING = 14;
gestaoEventosLexer.SEPARADOR = 15;


gestaoEventosLexer.modeNames = [ "DEFAULT_MODE" ];

gestaoEventosLexer.literalNames = [ null, "'Evento:'", "'Data:'", "'Hora:'", 
                                    "'Local: '", "'Descricao:'", "'Custo:'", 
                                    "'€'", "'Participantes:'", "','", "'.'", 
                                    "'-'", "':'" ];

gestaoEventosLexer.symbolicNames = [ null, null, null, null, null, null, 
                                     null, null, null, null, null, null, 
                                     null, "NUMERO", "STRING", "SEPARADOR" ];

gestaoEventosLexer.ruleNames = [ "T__0", "T__1", "T__2", "T__3", "T__4", 
                                 "T__5", "T__6", "T__7", "T__8", "T__9", 
                                 "T__10", "T__11", "NUMERO", "DIGITO", "STRING", 
                                 "SEPARADOR" ];

gestaoEventosLexer.grammarFileName = "eventos.g4";



exports.gestaoEventosLexer = gestaoEventosLexer;

